* StarFSub.s
* Viser stjerne p� sk�rmen, 32 farvers baggrund.
* bygger p� "StarFSide.s"
* Eneste forskel er den m�de hovedoobjektet bygges op p� - udseendet
* er identisk. I denne version sorteres underobjekterne ved hj�lp af
* et "fantom-underobjekt".

* Styring med joysticket:
*
* H�jre/Venstre: Rotation om Y-aksen
* Op/Ned: Rotation om X-aksen
* H�jre/Venstre m/skydeknapp nede: Rotation om Z-aksen

lnmod=40
line_lnmod=64
line_waitblit=-1	;Check altid om blitteren er f�rdig!

line_LnModMul:	macro
	lsl	#6,\1	;* 64, Aldrig negative koordinater
	endm

	include	VektorProgAmiga:Includes/custom.i
	include	VektorProgAmiga:Includes/line.s
	
OFF=0
ON=-1
debug:	set	OFF
mouse_wait:	set 	OFF

LnModMul:	MACRO	;Ganger \1 med 40
	asl	#3,\1	;\1=x*8
	move	\1,\2	;\2=x*8
	add	\1,\1	;\1=x*16
	add	\1,\1	;\1=x*32
	add	\2,\1	;\1=x*32+x*8=x*40
	ENDM


* Nogle konstanter fra EXEC og GRAPHICS - bibliotekerne:

* Fra Exec library:
_LVOOpenLibrary=-552
_LVOAllocMem=-198
_LVOFreeMem=-210
_LVOForbid=-132
_LVOPermit=-138

* Fra memory.i:
MEMF_PUBLIC=1
MEMF_CHIP=2
MEMF_CLEAR=65536

 * Fra Graphics library:
_LVOWaitBlit=-228
_LVOOwnBlitter=-456
_LVODisownBlitter=-462

* Fra DOS library:
MODE_OLDFILE=1005
_LVOOpen=-30
_LVORead=-42
_LVOClose=-36

	bsr	init_background

	IFEQ	debug-OFF
	move.l	$4.w,a6
	lea	gfxname,a1
	moveq	#0,d0
	jsr	_LVOOpenLibrary(a6)
	move.l	d0,gfxbase

	move.l	d0,a6
	jsr	_LVOWaitBlit(a6)
	jsr	_LVOOwnBlitter(a6)
	
	move.l	$4.w,a6
	jsr	_LVOForbid(a6)

	ENDC
	bsr	init_bitplanes
	bsr	init_copper
	bsr	init_vars
	bsr	init_blitter
	bsr	init_interrupts
	
* Her inds�ttes hovedprogrammet..

	bsr	init_triplebuf
	
	lea	var,a6	
main_loop:
	bsr	restore_oldpolys	;Skal vente p� klar-signal!
				;checker om draw_ready(a6) er 0. S� er
				;det klart...
	bsr	joystick_move
	lea	star,a0
	move	rx(a6),objRX(a0)
	move	ry(a6),objRY(a0)
	move	rz(a6),objRZ(a0)
	bsr	draw_mainobj	;roterer og tegner hovedobjektet
	bsr	triplebuf
	btst	#6,$bfe001
	bne.s	main_loop

 	IFEQ	debug-OFF
	move.l	gfxbase,a6
	jsr	_LVODisownBlitter(a6)
	
	move.l	4.w,a6
	jsr	_LVOPermit(a6)
	ENDC
	bsr	restore_copperlist
	bsr	remove_interrupts
	bsr	remove_background
	bsr	dealloc_mem	
	
	move	#$0400,dmacon+$dff000	;Slukker for blitter nasty.
	move	#$8020,dmacon+$dff000	;T�nder sprites igen!
Exit:
	moveq	#0,d0
	rts

shame_nobck_mem:
	addq.l	#4,sp
	moveq	#-100,d0
	rts	;returnerer UD AF programmet pga for lidt chip-hukommelse.

remove_background:
* reallokerer hukomelsen, som blev brugt af baggrundsgrafikken.
	move.l	4.w,a6
	move.l	colors_pointer+var,a1
	move.l	#51264,d0
	jsr	_LVOFreeMem(a6)
	rts

init_background:
* Indl�ser filen "background.raw" fra programdisketten og l�gger den
* bag objektet.
	move.l	4.w,a6
	move.l	#51264,d0
	move.l	#MEMF_CHIP+MEMF_PUBLIC,d1
	jsr	_LVOAllocMem(a6)
	move.l	d0,colors_pointer+var
	beq.s	shame_nobck_mem

	lea	backgr_bitplanes_table+var,a0
	add.l	#64,d0
	moveq	#4,d1
inbck_loop:
	move.l	d0,(a0)+
	add.l	#10240,d0
	dbra	d1,inbck_loop
	
	lea	dosname(pc),a1
	moveq	#0,d0
	jsr	_LVOOpenLibrary(a6)
 	move.l	d0,a6
	
	move.l	#gfxfile,d1
	move.l	#MODE_OLDFILE,d2
	jsr	_LVOOpen(a6)
	move.l	d0,d7	;d7=file-handle
	beq	shame_nosuchfile
	
	move.l	d7,d1
	move.l	colors_pointer+var,d2
	move.l	#51264,d3
	jsr	_LVORead(a6)
	
	move.l	d7,d1
	jsr	_LVOClose(a6)
	
	rts
shame_nosuchfile:
	bsr	remove_background
	addq.l	#4,sp
	moveq	#-50,d0
	rts	returnerer UD af programmet.

	
dosname:	dc.b	"dos.library",0
	even
gfxfile:	dc.b	"VektorProgAmiga:Background.raw",0
	even
	
init_interrupts:
* Slukker for alle level 3 interrupts bortset fra COPPER-interruptet.
* T�nder s� for COPPER-interruptet...
	IFEQ	debug-OFF
	move.l	$6c.w,old_int3handler(a6)
	move	intenar(a5),old_intena(a6)
	move	#$3fff,intena(a5)	;Slukker for vertical bl+copper intr.
	move.l	#int3_handler,$6c.w	;L�gger interrupthandleren ind
	move	#$c010,intena(a5)	;T�nder for copper-interrupt.
	ENDC
	rts

remove_interrupts:
* L�gger de gamle level 3 interrupt tilbage...
	IFEQ	debug-OFF
	move	old_intena+var,d0
	or	#$c000,d0
	move	#$0030,intena(a5)
	move.l	old_int3handler+var,$6c.w
	move	d0,intena(a5)
	ENDC
	rts
 
dealloc_mem:
* Reallokerer al hukommelsen, som blev allokeret i starten af programmet.
	
	move.l	4.w,a6	;A6=Exec-base

	move.l	copperlist_pointer+var,a1
	move.l	#copperlist_size,d0
	jsr	_LVOFreeMem(a6)
	
dealloc_screenmem:	;hopper her til, hvis allokeringen af copperlisthukommelsen
			;ikke g�r godt.
	move.l	#tempplane_size,d0
	move.l	tempplane_pointer+var,a1
	subq.l	#2,a1
	jsr	_LVOFreeMem(a6)

	lea	bitplane_table+var,a4
	
	moveq	#noof_bitplanes*noof_screens-1,d7
dealloc_bitplmem_loop:
	move.l	#bitplane_size,d0
dal_bpm:
	move.l	(a4)+,d1
	bmi.s	dal_bpm	;Vi har lagt nogle -1 ind...
	move.l	d1,a1	
	jsr	_LVOFreeMem(a6)
	dbra	d7,dealloc_bitplmem_loop
	rts

restore_copperlist:
* Henter copperlisten, som bliver brugt af Intuition-systemet
* i Amigaen, frem, s�dan at den s�dvanlige CLI/Workbench-sk�rm kommer til syne igen.

	move.l	4.w,a0
	move.l	156(a0),a0
	move.l	38(a0),cop1lch+$dff000
	move	copjmp1+$dff000,d0	;Og copperlisten er tilbage igen.
	rts
	
int3_handler:
* Interrupt level 3.
	pea	(a6)
	pea	(a5)
	move	d7,-(sp)
	
	move	#$0010,intena+$dff000
	
	lea	var,a6
 
	clr	draw_ready(a6)
	tst	newscreen_flag(a6)
	bne.s	int3_no_new_screen
	not	newscreen_flag(a6)

* Her l�gges nye sk�rmadresser ind i copperlisten.
* De tages fra bitplane-tabellen, hvorp� show_bitplanes_pointeren peger.
* Double- og triple-bufferingsrutinerne tager sig af indstillingen af
* denne pointer.

	move.l	show_bitplanes_table(a6),a5
	move.l	copperlist_pointer(a6),a6
	
	addq.l	#2,a6
	move	#noof_bitplanes-1,d7
int3_newaddrs_loop:
	move	(a5)+,(a6)
	move	(a5)+,4(a6)
	addq.l	#8,a6
	dbra	d7,int3_newaddrs_loop
int3_no_new_screen:

	
	move	#$3fff,intreq+$dff000	;Slukker for interrupt-requesten igen.
	move	#$8010,intena+$dff000

	move	(sp)+,d7
	move.l	(sp)+,a5
	move.l	(sp)+,a6
	rte	;returnerer fra interruptet.

joystick_move:
	move	$dff000+joy1dat,d0
	
	btst	#1,d0
	beq.s	jm_b1_ns	
	bchg	#0,d0
jm_b1_ns:
	btst	#9,d0
	beq.s	jm_b2_ns
	bchg	#8,d0
jm_b2_ns:

* Vi har n� ordnet det slik at:
* bit 0 = 1: bakover/nedover
* bit 1 = 1: h�yre
* bit 8 = 1: framover/oppover
* bit 9 = 1: venstre
* Vi checker s� om skydeknappen er trykket ned..

* F�rst tager vi en rotation runft om x-aksen, som styres af joystick op/ned.


	btst	#0,d0
	beq.s	not_bck
	
	add.l	#$8000,rxs(a6)
	bra.s	not_fwd
not_bck:
	btst	#8,d0
	beq.s	not_fwd
	
	sub.l	#$8000,rxs(a6)
not_fwd:


* S� skal vi f�rst checke skydeknappen f�r vi kan behandle
* venstre/h�jre bev�gelsen.
* Hvis skydeknappen er nede, skal det give en rotation rundt om Z-aksen,
* men hvis den er oppe, skal det give rotation om Y-aksen.

	btst	#7,$bfe001
	beq.s	joy_button_pressed

* Ok. Joystick-knappen er ikke nede. Da er en eventuel rotation rundt om Y-aksen

	btst	#1,d0
	beq.s	not_rig
	sub.l	#$8000,rys(a6)
	bra.s	not_lft
not_rig:
	btst	#9,d0
	beq.s	not_lft
	add.l	#$8000,rys(a6)
not_lft:

	bra.s	brake	;rutine som simulerer luftmodstand


joy_button_pressed:
	btst	#1,d0
	beq.s	bnot_rig
	add.l	#$8000,rzs(a6)
	bra.s	bnot_lft
bnot_rig:
	btst	#9,d0
	beq.s	bnot_lft
	sub.l	#$8000,rzs(a6)
bnot_lft:
brake:
	
 	move.l	rxs(a6),d0
	add.l	d0,rxl(a6)
	asr.l	#5,d0
	sub.l	d0,rxs(a6)
	
	move.l	rys(a6),d0
	add.l	d0,ryl(a6)
	asr.l	#5,d0
	sub.l	d0,rys(a6)
	
	move.l	rzs(a6),d0
	add.l	d0,rzl(a6)
	asr.l	#5,d0
	sub.l	d0,rzs(a6)
	
	move.w	#2046,d0
	
	move	rxl(a6),rx(a6)
	and	d0,rx(a6)
	move	ryl(a6),ry(a6)
	and	d0,ry(a6)
	move	rzl(a6),rz(a6)
	and	d0,rz(a6)
	rts

init_vars:
	lea	var,a6
	moveq	#-1,d0
	move.l	d0,set_to_minus1(a6)
	move	#$ff,poly_color(a6)
	rts

init_bitplanes:

noof_bitplanes=5	;antal bitplanes
noof_screens=3		;antal sk�rme (3 giver triple-buffering)
bitplane_size=320*256/8		;Giver bitplanst�rrelsen 320x256 pixels.
tempplane_size=512*512/8	;temp_plane st�rrelse 512x512 pixels

	move.l	4.w,a6	;A6=Exec-base

	move.l	#tempplane_size,d0
	move.l	#MEMF_CHIP+MEMF_CLEAR+MEMF_PUBLIC,d1
	jsr	_LVOAllocMem(a6)
	tst.l	d0
	beq	disaster_no_tempplanemem
	addq.l	#2,d0
	move.l	d0,tempplane_pointer+var

	lea	bitplane_table+var,a4
	
 	moveq	#noof_screens-1,d7
alloc_bitplmem_loop1:
	moveq	#noof_bitplanes-1,d6
alloc_bitplmem_loop2:
	move.l	#bitplane_size,d0
	move.l	#MEMF_CHIP+MEMF_CLEAR+MEMF_PUBLIC,d1
	jsr	_LVOAllocMem(a6)
	move.l	d0,(a4)+
	beq	disaster_no_bitplanemem
	dbra	d6,alloc_bitplmem_loop2
	move.l	#-1,(a4)+
	dbra	d7,alloc_bitplmem_loop1

	move.l	#bitplane_table+var,show_bitplanes_table+var
	
* Nu er det p� tide at kopiere baggrundsgrafikken ind:
	rts

disaster_no_bitplanemem:
* Uha da. Denne rutine tager sig af det problemet, som kan opst� hvis
* programmet k�res p� en maskine med for lidt CHIP-MEM.
* S� skal vi reallokere alle bitplanerne, som blev allokeret f�r vi g�r
* ud af programmet.

	lea	bitplane_table+var,a4
dealloc_nobplm_loop:
	move.l	(a4)+,d1
	beq	nobplm_deallocated
	bmi.s	dealloc_nobplm_loop	;Vi har lagt nogle -1 ind i listen.
	move.l	d1,a0
	move.l	#bitplane_size,d0
	jsr	_LVOFreeMem(a6)
	bra.s	dealloc_nobplm_loop
nobplm_deallocated:
	move.l	tempplane_pointer+var,a1
	subq.l	#2,a1
	move.l	#tempplane_size,d0
	jsr	_LVOFreeMem(a6)
disaster_no_tempplanemem:
	moveq	#-100,d0
	addq.l	#4,sp	;Vi returnerer direkte tilbage
	bra	remove_background

init_copper:
copperlist_size=200
* Maksimal l�ngde p� copperlisten er her sat til 200 bytes.
* Det burde v�re nok i de fleste tilf�lde, men hvis du beh�ver mere,
* skal du bare �ndre det.

 	move.l	$4.w,a6
	move.l	#MEMF_CHIP+MEMF_PUBLIC+MEMF_CLEAR,d1
	move.l	#copperlist_size,d0
	jsr	_LVOAllocMem(a6)
	move.l	d0,copperlist_pointer+var
	bne.s	ic_clm_alloc_ok
	
* Uha da. Ikke nok hukommelse til en copperliste!
* (Og det kan lade sig g�re..._)
	
	bsr	dealloc_screenmem
	addq.l	#4,sp
	bra	Exit
	
ic_clm_alloc_ok:
 	move.l	d0,a0	;a0=copperlist-start
 	move.l	d0,d7	;Lagrer i d7 til brug l�ngere nede...
 	
 	move	#bpl1pth,d1
 	moveq	#noof_bitplanes-1,d0
 	moveq	#0,d2
crcl_loop1:
	move	d1,(a0)+
	move	d2,(a0)+
	addq	#2,d1	;d1=bplxptl
	move	d1,(a0)+
	move	d2,(a0)+
	addq	#2,d1	;d1=n�ste bplxpth
	dbra	d0,crcl_loop1

* Nu er den f�rste del af copperlisten f�rdig - nemlig den del, som s�tter
* bitplane-adresse-registrene.

* Vi s�tter farverne i init_copper - rutinen

	move	#spr0ctl,(a0)+
	move	d2,(a0)+
	move	#spr1ctl,(a0)+
	move	d2,(a0)+	;Fjerner eventuelle sprite-rester...
	
* De n�ste 6 linier (kommentarlinierne skal ikke t�lles med)
* SKAL v�re med for at int3_handler skal kunne fungere...

	move.l	#$ffdffffe,(a0)+ ;Venter helt til sidst p� linie 256
	move.l	#$3509fffe,(a0)+
	move.l	#$3509fffe,(a0)+

* Venter p� linien nedenunder den nederste linie, som vises...
* Laver interrupt (copper interrupt), som udnyttes af int3_handler...
 
	move	#intreq,(a0)+
	move	#$8010,(a0)+	;copper interrupt...
	move.l	#$fffffffe,(a0)+	;Afslutter copperlisten.
	
	IFEQ	debug-OFF
	lea	$dff000,a5
	move	#$07a0,dmacon(a5)	;Slukker for alle DMA, copper og sprites..	
			;Slukker for blitter nasty, hvis den skulle v�re t�ndt.
	move	#$200+noof_bitplanes*$1000,bplcon0(a5)	
	move	#0,bpl1mod(a5)
	move	#0,bpl2mod(a5)

	move	#$0038,ddfstrt(a5)
	move	#$00d0,ddfstop(a5)
	move	#$2c81,diwstrt(a5)
	move	#$2cc1,diwstop(a5)

	move.l	d7,cop1lch(a5)	;d7 er starten p� copperlisten.
	move.w	copjmp1(a5),d0
	
	move	#$8380,dmacon(a5)	;T�nder for DMA og copper igen,
					;men ikke sprites.
* T�nder ogs� for blitter nasty.
* Det f�r programmet til at k�re en del hurtigere, da rutinerne
* ikke er lagt ind p� interrupt (blitteren kan indstilles til at
* lave interrupt n�r den er f�rdig med et "blit")

	moveq	#31,d0
	lea	$dff180,a0
	move.l	colors_pointer+var,a1
colors_loop:
	move	(a1)+,(a0)+
	dbra	d0,colors_loop

	ENDC
	rts
	
init_blitter:
	IFEQ	debug-OFF
	bsr	init_line
	move.l	#-1,bltafwm(a5)
	ENDC
	rts
	
wait_mouse:
	move	#10000,d0
wm1_loop:
	btst	#6,$bfe001
 	dbeq	d0,wm1_loop
	beq.s	wait_mouse
* OK. S� har knappen v�ret "oppe" i nogle ms
wm2_loop:
	btst	#6,$bfe001
	bne.s	wm2_loop
* Og nu er der blevet trykket p� knappen...
wm3_redo:
	move	#10000,d0
wm3_loop:
	btst	#6,$bfe001
	dbeq	d0,wm3_loop
	beq.s	wm3_redo	;Og den har v�ret oppe igen i nogle ms...
	rts

SinusTable:
	include	VektorProgAmiga:Includes/SinCosTable.s
CosinusTable=SinusTable+512


gfxbase:	ds.l	1
gfxname:	dc.b	"graphics.library",0
	even

StarCoords:
	dc.w		0,-200*2,0
	
	dc.w		-50*2,-50*2,-50*2
	dc.w		50*2,-50*2,-50*2
	dc.w		50*2,-50*2,50*2
	dc.w		-50*2,-50*2,50*2
	
	dc.w		0,0,-200*2
	dc.w		200*2,0,0
	dc.w		0,0,200*2
	dc.w		-200*2,0,0
 	
 	dc.w		-50*2,50*2,-50*2
	dc.w		50*2,50*2,-50*2
	dc.w		50*2,50*2,50*2
	dc.w		-50*2,50*2,50*2

	dc.w		0,200*2,0

StarCalcCoords:
	ds.w	14*3
StarDrawCoords:
	ds.l	14

star:
	dc.w	0,0,0,0,0 		;De 5 f�rste words bruges kun internt i optegningsrutinerne
	dc.w	0,0,0,0,0,0		;x, y og z-koordinater og rotationsvinkler...
	dc.w	13								;14 koordinater ialt
	      dc.l		StarCoords		;Adresse p� koordinattabellen
	dc.l		StarCalcCoords	:Adresse p� udregnings-koordinattabellen
	dc.l		StarDrawCoords	;Adresse p� optegnings-koordinattabellen
	dc.l		StarSubTable	;Adresse p� liste over alle underobjekterne
	dc.w	6	;7 underobjekt								;6 underobjekter (antal minus 1 skal opgives her!)

StarSubTable:
	dc.l	Phantom,StarUp,StarLf,StarFr,StarRg,StarBk,StarDn

Phantom:
	dc.w	0
	dc.w	5
	dc.l	 phant_up,phant_fr,phant_rg,phant_bk,phant_lf,phant_dn
	
StarUp:
	dc.w	0
	dc.w	3	;5 sideflader i hver "tak"
	dc.l		upPoly0,upPoly1,upPoly2,upPoly3

StarLf:
	dc.w	0
	dc.w	3
	dc.l	lfPoly0,lfPoly1,lfPoly2,lfPoly3

StarFr:
	dc.w	0
	dc.w	3
	dc.l	frPoly0,frPoly1,frPoly2,frPoly3

StarRg:
	dc.w	0
	dc.w	3
	dc.l	rgPoly0,rgPoly1,rgPoly2,rgPoly3

StarBk:
	dc.w	0
	dc.w	3
	dc.l	bkPoly0,bkPoly1,bkPoly2,bkPoly3

StarDn:
	dc.w	0
	dc.w	3
	dc.l	dnPoly0,dnPoly1,dnPoly2,dnPoly3


phant_up:
	dc.w	0
	dc.b	-1,-1	;usynlig p� begge sider - "fantomflade"
	dc.l	0
	dc.w	0	;et underobjekt som ligger foran
	dc.l	phant_up_table
	dc.w	3
	dc.w	1*4,4*4,3*4,2*4
phant_up_table:	dc.l	StarUp
	
phant_fr:
	dc.w	0
	dc.b	-1,-1	;usynlig p� begge sider - "fantomflade"
	dc.l	0
	dc.w	0	;et underobjekt som ligger foran
	dc.l	phant_fr_table
	dc.w	3
	dc.w	1*4,2*4,9*4,10*4
phant_fr_table:	dc.l	StarFr

phant_rg:
	dc.w	0
	dc.b	-1,-1	;usynlig p� begge sider - "fantomflade"
	dc.l	0
	dc.w	0	;et underobjekt som ligger foran
	dc.l	phant_rg_table
	dc.w	3
	dc.w	2*4,3*4,11*4,10*4
phant_rg_table:	dc.l	StarRg

phant_bk:
	dc.w	0
	dc.b	-1,-1	;usynlig p� begge sider - "fantomflade"
	dc.l	0
	dc.w	0	;et underobjekt som ligger foran
	dc.l	phant_bk_table
	dc.w	3
	dc.w	3*4,4*4,12*4,11*4
phant_bk_table:	dc.l	StarBk
	
phant_lf:
	dc.w	0
	dc.b	-1,-1	;usynlig p� begge sider - "fantomflade"
	dc.l	0
	dc.w	0	;et underobjekt som ligger foran
	dc.l	phant_lf_table
	dc.w	3
	dc.w	4*4,1*4,9*4,12*4
phant_lf_table:	dc.l	StarLf
	
phant_dn:
	dc.w	0
	dc.b	-1,-1	;usynlig p� begge sider - "fantomflade"
	dc.l	0
 	dc.w	0	;et underobjekt som ligger foran
	dc.l	phant_dn_table
	dc.w	3
	dc.w	9*4,10*4,11*4,12*4
phant_dn_table:	dc.l	StarDn


upPoly0:
	dc.w		0
	dc.b		1,-1							;Forsidefarve 1, bagsiden usynlig.
	dc.l		0									;Ingen flader i samme plan
	dc.w		-1									;Ingen underobjekter foran denne sideflade
	dc.l		0
	dc.w		2									;Trekant
	dc.w		1*4,0,2*4			;Koordinaterne 1-0-2

upPoly1:
	dc.w		0
 	dc.b		2,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		2*4,0,3*4			;2-0-3

upPoly2:
	dc.w		0
	dc.b		3,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		3*4,0,4*4			;3-0-4
upPoly3:
	dc.w		0
	dc.b		4,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		4*4,0,1*4			;4-0-1


lfPoly0:
	dc.w		0
	dc.b		5,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		8*4,1*4,9*4	;Koordinaterne 8-1-9
 
lfPoly1:
	dc.w		0
	dc.b		6,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		8*4,4*4,1*4	;8-4-1

lfPoly2:
	dc.w		0
	dc.b		7,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		4*4,8*4,12*4	;4-8-12

lfPoly3:
	dc.w		0
	dc.b		8,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		8*4,9*4,12*4	;8-9-12

frPoly0:
	dc.w		0
	dc.b		9,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		1*4,2*4,5*4	;Koordinaterne 1-2-5

frPoly1:
	dc.w		0
	dc.b		10,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		2*4,10*4,5*4	;2-10-5

frPoly2:
	dc.w		0
	dc.b		11,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		5*4,10*4,9*4	;5-10-9
 
frPoly3:
	dc.w		0
	dc.b		12,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		1*4,5*4,9*4	;1-5-9

rgPoly0:
	dc.w		0
	dc.b		13,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		2*4,3*4,6*4	;Koordinaterne 2-3-6

rgPoly1:
	dc.w		0
	dc.b		14,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		6*4,3*4,11*4	;6-3-11

rgPoly2:
	dc.w		0
	dc.b		15,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		10*4,6*4,11*4	;10-6-11

rgPoly3:
	dc.w		0
	dc.b		16,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
 	dc.w		2*4,6*4,10*4	;2-6-10

bkPoly0:
	dc.w		0
	dc.b		17,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
 	dc.w		3*4,4*4,7*4	;Koordinaterne 3-4-7

bkPoly1:
	dc.w		0
	dc.b		18,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		7*4,4*4,12*4	;7-4-12

bkPoly2:
	dc.w		0
	dc.b		19,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		11*4,7*4,12*4	;11-7-12

bkPoly3:
	dc.w		0
	dc.b		20,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		3*4,7*4,11*4	;3-7-11

dnPoly0:
	dc.w		0
	dc.b		21,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		9*4,10*4,13*4	;Koordinaterne 9-10-13
dnPoly1:
	dc.w		0
	dc.b		22,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		10*4,11*4,13*4	;10-11-13

dnPoly2:
	dc.w		0
	dc.b		23,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		11*4,12*4,13*4	;11-12-13
 
dnPoly3:
	dc.w		0
	dc.b		24,-1
	dc.l		0
	dc.w		-1
	dc.l		0
	dc.w		2
	dc.w		12*4,9*4,13*4	;12-9-13

	include	VektorProgAmiga:sources/obj.s
	include	VektorProgAmiga:sources/poly.s

ofsreset:	macro
ofs_ofs:	SET	0
	endm
	
ofs:	macro
\1=ofs_ofs
ofs_ofs:	SET	ofs_ofs+\2
	endm
	
* ofs og ofsreset f�r her samme funktion som rs og rsreset i DEVPAC...
* ofs og ofsreset fungerer imidlertid p� alle assemblere (ikke SEKA)..

	ofsreset

	ofs copperlist_pointer,4
	ofs tempplane_pointer,4
	ofs show_bitplanes_table,4
	ofs bitplane_table_pointer,0	;Samme som show_bitplanes_table
	ofs draw_bitplanes_table,4
	ofs visibl_bitplanes_table,4
	ofs show_minx,2
	ofs show_miny,2
	ofs show_maxx,2
	ofs show_maxy,2
	ofs draw_minx,2
	ofs draw_miny,2
	ofs draw_maxx,2
	ofs draw_maxy,2
	ofs visibl_minx,2
	ofs visibl_miny,2
	ofs visibl_maxx,2
	ofs visibl_maxy,2
	
	ofs newscreen_flag,2
	ofs poly_minx,2	;poly_minx, miny, maxx og maxy skal
	ofs poly_miny,2	;st� lige efter hinanden!
	ofs poly_maxx,2	;ellers vil poly-rutinerne ikke fungere
	ofs poly_maxy,2	;ordentligt!!!
 
	ofs rx,2
	ofs ry,2
	ofs rz,2
	ofs rxl,4
	ofs ryl,4
	ofs rzl,4
	ofs rxs,4
	ofs rys,4
	ofs rzs,4
	ofs cosx,2
	ofs sinx,2
	ofs cosy,2
	ofs siny,2
	ofs cosz,2
	ofs sinz,2
	
	ofs old_dot_offsets,16
	
	ofs draw_ready,2

	ofs del_height,2
	ofs del_width,2
	ofs fill_width,2
	ofs copy_width,2
	ofs fill_offset,2
	ofs fill_height,2
	ofs copy_srcoffset,2
	ofs colors_pointer,4
	ofs backgr_bitplanes_table,4*noof_bitplanes
	ofs bitplane_table,4*noof_bitplanes*(noof_screens+1) ;S�t inn -1 etter hver!
	ofs copy_destoffset,2
	ofs poly_color,2
	ofs objline_table,200
	ofs current_mainobj,4
	ofs old_intena,2
	ofs old_int3handler,4
	ofs dest_coords,900	
	ofs set_to_minus1,4	;-1 skal st� lige f�r line_table!
				;Linietegningsrutinen tegner linier bagfra
				;indtil den kommer til et negativt tal.
	ofs line_table,400	;dvs maks 50 hj�rner i et polygon.
				;Hvis du beh�ver flere, skal du lave
				;dette array l�ngere.
	ofs hardware_fake,400
	ofs var_size,0

	section	buffer,bss
var:	
	ds.b	var_size
